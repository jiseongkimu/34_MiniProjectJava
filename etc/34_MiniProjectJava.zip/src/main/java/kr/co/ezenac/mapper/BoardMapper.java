package kr.co.ezenac.mapper;

public interface BoardMapper {

}
